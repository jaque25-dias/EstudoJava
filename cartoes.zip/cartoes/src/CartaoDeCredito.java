
public interface CartaoDeCredito {
	
	public boolean validaCartao(String numero);
	
}

public class TestaCartao {

	public static void main(String[] args) {
		
		
			
	}
}

package figuraGeometrica;

public abstract class figura2D extends figuraGeometricaJava implements dimensaoSuperficial{

	
}

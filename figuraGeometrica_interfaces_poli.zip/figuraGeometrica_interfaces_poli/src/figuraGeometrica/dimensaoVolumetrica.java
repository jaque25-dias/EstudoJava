package figuraGeometrica;

public interface dimensaoVolumetrica {

double calcularVolume();
		
	}

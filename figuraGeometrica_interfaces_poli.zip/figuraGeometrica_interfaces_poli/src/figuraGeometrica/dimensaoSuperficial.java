package figuraGeometrica;

public interface dimensaoSuperficial {

	
	double calcularArea();
		

}

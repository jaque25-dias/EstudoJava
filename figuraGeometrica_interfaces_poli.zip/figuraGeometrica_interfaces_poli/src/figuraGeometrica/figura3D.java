package figuraGeometrica;

public abstract class figura3D extends figuraGeometricaJava implements dimensaoVolumetrica, dimensaoSuperficial{

}

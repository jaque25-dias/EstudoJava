package br.com.cit.bootcamp.aula02;

public enum Cargo{
	DBA,
	DESENVOLVEDOR,
	TESTER,
	ESTAGIARIO
}


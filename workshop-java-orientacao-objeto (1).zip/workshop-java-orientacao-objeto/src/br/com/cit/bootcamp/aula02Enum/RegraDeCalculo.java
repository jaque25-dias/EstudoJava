package br.com.cit.bootcamp.aula02Enum;

public interface RegraDeCalculo {
	double calcula(Funcionario funcionario);
}

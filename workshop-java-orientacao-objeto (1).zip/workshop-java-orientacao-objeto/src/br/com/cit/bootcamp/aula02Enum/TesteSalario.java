package br.com.cit.bootcamp.aula02Enum;

import java.util.Scanner;

public class TesteSalario {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        Funcionario funcionario = new Funcionario();
        
        System.out.println("Informe seu nome: ");
        String nome = leia.nextLine();
        funcionario.setNome(nome);

        System.out.println("Informe seu cargo, conforme as opções abaixo: ");
        System.out.println("DBA");
        System.out.println("DESENVOLVEDOR");
        System.out.println("TESTER");
        System.out.println("ESTAGIARIO");
        System.out.println("DIRETOR");
        System.out.println("GERENTE");


        String cargo = leia.nextLine();
        // Outra forma de recuperar o enum baseado em uma String Exemplo: DBA = Cargo.DBA
        try {
        	funcionario.setCargo(Cargo.valueOf(cargo));
        }catch (Exception e) {
			 throw new IllegalArgumentException("O cargo informado não é valido.");
		}

        System.out.println("Informe seu salário: ");
        double salario = leia.nextDouble();
        funcionario.setSalarioBase(salario);
        
        leia.close();

      
        double salarioReajustado = funcionario.reajustaSalario();
        System.out.println(nome + ". Seu novo salário é: R$ " + salarioReajustado);
    }
}
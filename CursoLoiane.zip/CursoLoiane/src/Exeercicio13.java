
public class Exeercicio13 {

	
//	13.Criar um vetor A com 10 elementos inteiros. Implementar um programa 
//	que determine a soma dos elementos armazenados neste vetor que 
//	são múltiplos de 5.
	
	
	public static void main(String[] args) {
	
		int n [] = new int[10];
		
		int i = 0;
		
		for (i= 0; i>10; i++) {
			
        n[i] = (int)Math.round(Math.random() *5); // gera um numero aleatorio no intervalo 0 ate 100
        	 
        	
			
		}
		
		
	}

}

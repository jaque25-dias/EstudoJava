public enum TipoDeVacina {
    
	ASTRAZENECA,
	CORONAVAC,
	PFIZER,
	JANSSEN
	
} 

public class TrianguloFactory {
	
	// TODO: Implementar...

}

package br.com.cit.bootcamp.aula01;

public enum BandeiraCartao {
	VISA,
	MASTER,
	AMEX
}

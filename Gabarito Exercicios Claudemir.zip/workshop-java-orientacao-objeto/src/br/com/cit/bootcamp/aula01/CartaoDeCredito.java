package br.com.cit.bootcamp.aula01;

public interface CartaoDeCredito {
	Boolean validaCartao(String numero);
}

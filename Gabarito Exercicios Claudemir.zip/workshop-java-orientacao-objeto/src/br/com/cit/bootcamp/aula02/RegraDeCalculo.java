package br.com.cit.bootcamp.aula02;

public interface RegraDeCalculo {
	double calcula(Funcionario funcionario);
}

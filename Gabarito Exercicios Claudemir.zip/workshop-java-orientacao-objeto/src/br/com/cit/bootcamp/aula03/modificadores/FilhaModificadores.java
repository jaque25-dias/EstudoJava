package br.com.cit.bootcamp.aula03.modificadores;

public class FilhaModificadores extends MeusModificadores {
	
	public void ImprimeMetodo()
	{
		this.imprimeMetodoProtected();
	}

}

package br.com.cit.bootcamp.aula03.modificadores;

public class MeusModificadores {
	
	protected void imprimeMetodoProtected()
	{
		System.out.println("Metodo protected");
	}
	
	

}

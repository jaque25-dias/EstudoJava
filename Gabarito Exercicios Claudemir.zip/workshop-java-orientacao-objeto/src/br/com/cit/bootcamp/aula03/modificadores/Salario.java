package br.com.cit.bootcamp.aula03.modificadores;

public class Salario {
	
	private double salario;

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	
	
}

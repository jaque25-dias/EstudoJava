package br.com.cit.bootcamp.aula03Parte2;

public class CalculaImposto {
	
	// ICMS = 20%
	// ISS = 15%
	// TX = 10%
	public double calculaImposto(Orcamento orcamento)
	{
		return 0;
	}
}

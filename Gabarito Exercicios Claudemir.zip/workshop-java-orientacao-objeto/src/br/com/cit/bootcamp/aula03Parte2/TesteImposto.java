package br.com.cit.bootcamp.aula03Parte2;

public class TesteImposto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

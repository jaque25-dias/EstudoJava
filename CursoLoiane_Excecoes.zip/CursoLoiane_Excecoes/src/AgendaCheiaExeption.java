
public class AgendaCheiaExeption extends Exception {

	public String getMessage() {
		return "A agenda já está Cheia";
	}
}

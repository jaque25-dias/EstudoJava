
public class Contador01 {

	static int conta;
	
	public  static  void zerar(){
	   conta=0;
	   
	}
	
  public static void incrementa() {
	  conta++;
  }
  
  public static int retornaValor(){
	  return conta;
  }
}